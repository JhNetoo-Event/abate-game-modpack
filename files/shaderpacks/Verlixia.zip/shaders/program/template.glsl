/* 
Verlixia Shaders - Based on BSL v8 by Capt Tatsu
Custom atmosphere, lighting, and color grading
*/ 

//Settings//
#include "/lib/settings.glsl"

//Fragment Shader///////////////////////////////////////////////////////////////////////////////////
#ifdef FSH

//Varyings//

//Uniforms//

//Attributes//

//Optifine Constants//

//Common Variables//

//Common Functions//

//Includes//

//Program//
void main() {
    
}

#endif

//Vertex Shader/////////////////////////////////////////////////////////////////////////////////////
#ifdef VSH

//Varyings//

//Uniforms//

//Attributes//

//Optifine Constants//

//Common Variables//

//Common Functions//

//Includes//

//Program//
void main() {
    
}

#endif
