/* 
Verlixia Shaders - Based on BSL v8 by Capt Tatsu
Custom atmosphere, lighting, and color grading
*/

//Settings//
#include "/lib/settings.glsl"

//Fragment Shader///////////////////////////////////////////////////////////////////////////////////
#ifdef FSH

//Varyings//
varying vec2 texCoord;

//Uniforms//
uniform sampler2D colortex1;

uniform float viewWidth, viewHeight;
uniform float aspectRatio, frameTimeCounter;
uniform float darknessFactor;
uniform sampler2D noisetex;

//Optifine Constants//
/*
const int colortex0Format = R11F_G11F_B10F; //main scene
const int colortex1Format = RGB8; //raw translucent, vl, bloom, final scene
const int colortex2Format = RGBA16; //temporal data
const int colortex3Format = RGB8; //smoothness, sky occlusion, entity mask
const int gaux1Format = R8; //cloud alpha, ao
const int gaux2Format = RGB10_A2; //reflection image
const int gaux3Format = RGBA16; //opaque normals, refraction vector
const int gaux4Format = RGBA16; //fresnel
const int colortex8Format = RGB8; //colored light
const int colortex9Format = RGB16F; //colored light
*/

const bool shadowHardwareFiltering = true;
const float shadowDistanceRenderMul = 1.0;

const int noiseTextureResolution = 512;

const float drynessHalflife = 5.0;
const float wetnessHalflife = 30.0;

//Common Functions//
#ifdef TAA
vec2 sharpenOffsets[4] = vec2[4](
	vec2( 1.0,  0.0),
	vec2( 0.0,  1.0),
	vec2(-1.0,  0.0),
	vec2( 0.0, -1.0)
);

void SharpenFilter(inout vec3 color, vec2 coord) {
	float mult = MC_RENDER_QUALITY * 0.0625;
	vec2 view = 1.0 / vec2(viewWidth, viewHeight);

	vec3 mincolor = color;
	vec3 maxcolor = color;

	color *= mult * 4.0 + 1.0;

	for(int i = 0; i < 4; i++) {
		vec2 offset = sharpenOffsets[i] * view;
		vec3 colorSample = texture2DLod(colortex1, coord + offset, 0).rgb;
		color -= colorSample * mult;

		mincolor = min(mincolor, colorSample);
		maxcolor = max(maxcolor, colorSample);
	}

	color = clamp(color, mincolor, maxcolor);
}
#endif

#ifdef SHADOW
#endif

//Program//
void main() {
    vec2 newTexCoord = texCoord;
	
	#ifdef RETRO_FILTER
    vec2 view = vec2(viewWidth, viewHeight) / float(RETRO_FILTER_SIZE);
	float offset = (ceil(RETRO_FILTER_SIZE * 0.5) - 0.5) / float(RETRO_FILTER_SIZE);
	newTexCoord = (floor(newTexCoord * view) + offset) / view;
	#endif

	vec3 color = texture2DLod(colortex1, newTexCoord, 0).rgb;

	#if CHROMATIC_ABERRATION > 0
	float caStrength = 0.004 * CHROMATIC_ABERRATION;
	vec2 caScale = vec2(1.0 / aspectRatio, 1.0);
	color *= vec3(0.0,1.0,0.0);
	color += texture2DLod(colortex1, mix(newTexCoord, vec2(0.5), caScale * -caStrength), 0).rgb * vec3(1.0,0.0,0.0);
	color += texture2DLod(colortex1, mix(newTexCoord, vec2(0.5), caScale * -caStrength * 0.5), 0).rgb * vec3(0.5,0.5,0.0);
	color += texture2DLod(colortex1, mix(newTexCoord, vec2(0.5), caScale * caStrength * 0.5), 0).rgb * vec3(0.0,0.5,0.5);
	color += texture2DLod(colortex1, mix(newTexCoord, vec2(0.5), caScale* caStrength), 0).rgb * vec3(0.0,0.0,1.0);

	color /= vec3(1.5,2.0,1.5);
	#endif
	
	#if defined FXAA && defined TAA
	SharpenFilter(color, newTexCoord);
	#endif

	// Verlixia: cinematic split-toning — cyan shadows, peach highlights
	float finalLuma = dot(color, vec3(0.299, 0.587, 0.114));
	vec3 splitShadow    = vec3(0.92, 0.98, 1.06); // cyan-blue push in darks
	vec3 splitHighlight = vec3(1.06, 1.02, 0.94); // warm peach in brights
	float splitBlend = smoothstep(0.0, 1.0, finalLuma);
	color *= mix(splitShadow, splitHighlight, splitBlend);
	color = clamp(color, 0.0, 1.0);

	// Verlixia: Cinematic darkness effect rework — desaturation, CA spike, grain, cold tint, vignette
	if (darknessFactor > 0.0) {
		float d = darknessFactor;

		// Desaturation
		float dLuma = dot(color, vec3(0.299, 0.587, 0.114));
		color = mix(color, vec3(dLuma), d * 0.85);

		// Cold color tint
		color *= mix(vec3(1.0), vec3(0.72, 0.88, 1.08), d * 0.7);

		// Chromatic aberration spike
		float caD = d * 0.012;
		vec2 caDir = (newTexCoord - 0.5) * vec2(1.0 / aspectRatio, 1.0);
		vec3 caColor;
		caColor.r = texture2DLod(colortex1, newTexCoord - caDir * caD, 0).r;
		caColor.g = color.g;
		caColor.b = texture2DLod(colortex1, newTexCoord + caDir * caD, 0).b;
		color = mix(color, caColor, d);

		// Film grain boost
		vec2 grainCoord = newTexCoord + fract(vec2(frameTimeCounter * 0.01723, frameTimeCounter * 0.02947));
		float grain = texture2D(noisetex, grainCoord * vec2(viewWidth, viewHeight) / 512.0).r * 2.0 - 1.0;
		color += grain * d * 0.07;

		// Vignette crush
		vec2 vigCoord = (newTexCoord - 0.5) * vec2(aspectRatio, 1.0);
		float vignette = dot(vigCoord, vigCoord);
		vignette = vignette * vignette;
		color *= 1.0 - vignette * d * 1.3;

		color = clamp(color, 0.0, 1.0);
	}

	gl_FragColor = vec4(color, 1.0);
}

#endif

//Vertex Shader/////////////////////////////////////////////////////////////////////////////////////
#ifdef VSH

//Varyings//
varying vec2 texCoord;

//Program//
void main() {
	texCoord = gl_MultiTexCoord0.xy;
	
	gl_Position = ftransform();
}

#endif