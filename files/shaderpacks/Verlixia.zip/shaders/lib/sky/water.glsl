#if (WATER_MODE == 1 || WATER_MODE == 3) && !defined SKY_VANILLA && (!defined NETHER || !defined NETHER_VANILLA)
uniform vec3 fogColor;
#endif

vec4 GetWaterFog(vec3 viewPos) {
    float fogDist = length(viewPos);
    float fog = fogDist / waterFogRange;
    fog = 1.0 - exp(-2.5 * fog * fog);
    
    #if WATER_MODE == 0 || WATER_MODE == 2
    vec3 waterFogColor = waterColor.rgb * waterColor.a;
    #elif  WATER_MODE == 1 || WATER_MODE == 3
    vec3 waterFogColor = fogColor * fogColor * 0.125;
    #endif
    waterFogColor *= WATER_F * WATER_F * (1.0 - max(blindFactor, darknessFactor));

    // Verlixia: sapphire-teal underwater with depth-based darkening
    vec3 sapphireTeal = vec3(0.15, 0.55, 0.65);
    float depthDarken = 1.0 - 0.5 * clamp(fogDist / waterFogRange, 0.0, 1.0);
    waterFogColor = mix(waterFogColor, sapphireTeal * waterFogColor, 0.6) * depthDarken;

    #ifdef OVERWORLD
    vec3 waterFogTint = lightCol * eBS * shadowFade * 0.95 + 0.1;
    // Verlixia: blue-shifted underwater light
    waterFogTint *= vec3(0.80, 0.90, 1.15);
    #endif
    #ifdef NETHER
    vec3 waterFogTint = netherCol.rgb;
    #endif
    #ifdef END
    vec3 waterFogTint = endCol.rgb;
    #endif
    waterFogTint = sqrt(waterFogTint * length(waterFogTint));

    return vec4(waterFogColor * waterFogTint, fog);
}